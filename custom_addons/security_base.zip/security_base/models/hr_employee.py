from odoo import api, fields, models


class HrEmployee(models.Model):
    _inherit = "hr.employee"

    security_guard = fields.Boolean(default=False, tracking=True)
    security_grade_id = fields.Many2one("security.grade", tracking=True)
    security_certification_ids = fields.Many2many(
        "security.certification",
        "hr_employee_security_certification_rel",
        "employee_id",
        "certification_id",
        string="Certifications",
    )
    security_language_ids = fields.Many2many(
        "security.language",
        "hr_employee_security_language_rel",
        "employee_id",
        "language_id",
        string="Language Skills",
    )
    security_attribute_ids = fields.Many2many(
        "security.attribute",
        "hr_employee_security_attribute_rel",
        "employee_id",
        "attribute_id",
        string="Attributes",
    )
    security_reliability_score = fields.Integer(default=100, tracking=True)
    security_home_location = fields.Char()
    security_medical_fitness_grade = fields.Char()
    security_disqualified = fields.Boolean(default=False, tracking=True)
    security_disqualification_reason_id = fields.Many2one(
        "security.disqualification.reason",
        tracking=True,
    )
    security_disqualification_note = fields.Text()
    security_reliability_adjustment_ids = fields.One2many(
        "security.reliability.adjustment",
        "employee_id",
        string="Reliability Adjustments",
    )
    security_reliability_adjustment_total = fields.Integer(
        compute="_compute_security_reliability_adjustment_total"
    )

    @api.depends("security_reliability_adjustment_ids.score_delta")
    def _compute_security_reliability_adjustment_total(self):
        for employee in self:
            employee.security_reliability_adjustment_total = sum(
                employee.security_reliability_adjustment_ids.mapped("score_delta")
            )
