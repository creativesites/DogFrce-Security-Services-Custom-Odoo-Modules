{
    "name": "Security Attendance",
    "summary": "Scheduled versus actual attendance for security roster slots",
    "version": "19.0.1.0.0",
    "category": "Human Resources",
    "author": "Winston Zulu",
    "license": "LGPL-3",
    "depends": ["security_operations", "web"],
    "data": [
        "security/ir.model.access.csv",
        "views/security_attendance_views.xml",
        "views/security_attendance_client_actions.xml",
        "views/security_awol_heatmap_actions.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "security_attendance/static/src/css/posting_console.css",
            "security_attendance/static/src/js/posting_console.js",
            "security_attendance/static/src/xml/posting_console.xml",
            "security_attendance/static/src/js/awol_heatmap.js",
            "security_attendance/static/src/xml/awol_heatmap.xml",
        ],
    },
    "installable": True,
    "application": False,
    "test": ["tests/test_shift_split.py"],
}
